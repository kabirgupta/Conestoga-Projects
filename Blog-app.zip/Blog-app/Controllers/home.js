const BlogPost=require("../models/BlogPost")

module.exports = async (req, res) =>{//get url
const blogposts = await BlogPost.find({})
console.log(req.session)
res.render('index',{
	blogposts //it is in JSON format
   
   });
}

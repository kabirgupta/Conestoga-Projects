module.exports= (req,res)=>{
	res.render('login')//this login is the login.ejs page
}
//packages

const express= require('express')
const path= require('path')
const ejs= require('ejs')
const mongoose= require('mongoose');
const fileUpload= require('express-fileupload')
const expressSession= require('express-session')
const flash= require('connect-flash')


//controllers
const homeController=require('./Controllers/home')
const newPostController=require('./Controllers/newPost')
const storePostController=require('./Controllers/storePost')
const getPostController=require('./Controllers/getPost')
//controllers for register/login
const newUserController=require('./Controllers/newUser')
const storeUserController=require('./Controllers/storeUser')
const loginController= require('./Controllers/login')
const loginUserController= require('./Controllers/loginUser')
const logoutController= require('./Controllers/logout')


//Files models
const BlogPost=require("./models/BlogPost")

//connect app to the MongoDB Database
mongoose.connect('mongodb+srv://admin:admin@cluster0.vkyc0tw.mongodb.net/Blog-app?retryWrites=true&w=majority')
//update username and Password, add db name before ?

//start express app with function

const app= express()
app.set('view engine', 'ejs')

//custom middlewares
const validateMiddleWare= require('./middleware/validationMiddleware')
const authMiddleWare= require('./middleware/authMiddleware')
const redirectAuthenticatedMiddleWare= require('./middleware/redirectAuthenticated')
//middlewares
app.use(express.json())
app.use(express.urlencoded({extended:true}))
app.use(fileUpload())
app.use('/posts/store',validateMiddleWare)
app.use(expressSession({
	secret:'I love express' 
}))
app.use(flash())

//accessible throughout the application
global.loggedIn=null

app.use("*",(req,res,next)=>{
	loggedIn=req.session.userId;
	next()
})


//static files

app.use(express.static('public'))

//start server
app.listen('4000',()=>{
	console.log('App is running on the port 4000')
})

//routes
app.get('/',homeController)
//authMiddleware was for the user who did not login/register
app.get('/post/:id',getPostController)

app.get('/posts/new',authMiddleWare,newPostController)

app.post('/posts/store',authMiddleWare,storePostController)

//routes for register/login
//redirctIf middleware is for user has logged in already 
app.get('/auth/register',redirectAuthenticatedMiddleWare,newUserController)

app.post('/users/register',redirectAuthenticatedMiddleWare,storeUserController)

app.get('/auth/login',redirectAuthenticatedMiddleWare,loginController)

app.post('/users/login',redirectAuthenticatedMiddleWare,loginUserController)

app.get('/auth/logout',logoutController)

app.use((req,res)=>res.render('notfound'))

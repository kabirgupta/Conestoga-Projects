const mongoose= require('mongoose');
const Schema= mongoose.Schema;

//first schema

const BlogPostSchema= new Schema({ //define the structure of application
	title: String,
	body: String,
	username: String,
	datePosted: {
		type: Date,
		default: new Date()
	},
	image: String
});

//link this schema with the collection

const BlogPost= mongoose.model('BlogPost', BlogPostSchema); //(name of collection, name of your schema)

module.exports=BlogPost

//Create Read update and Delete (CRUD)
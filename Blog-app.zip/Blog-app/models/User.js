const mongoose= require('mongoose');
const Schema= mongoose.Schema;
const uniqueValidator= require('mongoose-unique-validator')
const bcrypt= require('bcrypt')

//second schema

const UserSchema= new Schema({ //define the structure of application
	username:{
		type:String,
		required: [true, "Please Enter Username"],
		unique: true
	},
	password:{
		type: String,
		required: [true, "Please Enter password"]
	}
});

UserSchema.plugin(uniqueValidator)

//before saving add functionality
//this is a middleware
//10 times will be encrypted (password)

UserSchema.pre('save',function(next){
	const user= this
	bcrypt.hash(user.password,10, (error,hash) => {
		user.password= hash
		next()
	})
})

//link this schema with the collection

const User= mongoose.model('User', UserSchema); //(name of collection, name of your schema)

module.exports=User

//Create Read update and Delete (CRUD)
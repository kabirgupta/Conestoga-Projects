import 'package:flutter/material.dart';
import 'package:test_11/screen/product_list.dart';
import 'package:test_11/screen/splash_screen.dart';
import 'screen/checkout_screen.dart';
import 'screen/confirmation_screen.dart';
import 'screen/login_screen.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context){
    return MaterialApp(
      home: const SplashScreen(),
      routes: {
        '/products': (context) => ProductListPage(),
        '/checkout' : (context) => const CheckoutScreen(),
        '/confirmation' : (context) => const ConfirmationScreen(),
        '/login' : (context) => const LoginScreen()
      },
    );
  }
}

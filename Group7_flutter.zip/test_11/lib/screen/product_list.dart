import 'package:flutter/material.dart';
import 'package:test_11/screen/product_details.dart';
import '../class/product.dart';

class ProductListPage extends StatelessWidget {
  final List<Product> products = [
    Product(
      name: 'Pleated Tennis Skirts',
      price: 33.99,
      category: 'Women',
      brand: 'Vivarium ',
      description: 'GLOTZL sorts skirts for women with high waist and cute v-shaped cross waistband will greatly smooth your belly and streamline your waists curve, keeping the sorts right in place while bending or squatting. Two side pockets on shorts are for storing your phone and ball.',
      imageUrl: 'images/tennis.jpg',
    ),
    Product(
      name: 'Adrianna Pap ell Women Beaded Blouse Dress',
      price: 29.99,
      category: 'Women',
      brand: 'Adrianna',
      description: 'Chic and iconic, a floor-sweeping, signature blouse gown, made to gently streamline the waist and blouse gently over it',
      imageUrl: 'images/dress.jpg',
    ),
    Product(
      name: 'Cape Dress for Women',
      price: 52.99,
      category: 'Women',
      brand: 'KIM-CURVY',
      description: 'Sleeveless with the flattering chiffon caplet design, the plus size body con dress covers the parts you may want to hide and accents the good parts, which would well decorate your arms and upper body.',
      imageUrl: 'images/dress2.jpg',
    ),
    Product(
      name: 'Nike Mens High-Top Sneakers Basketball Shoes',
      price: 512.99,
      category: 'Men',
      brand: 'Nike',
      description: 'Inspired by the 1985 original, the Air Jordan 1 Mid Mens shoe is reminiscent of the revolutionary model that accompanied MJ from the freshman season to the All-Star debut. The new materials and colors give it a new look that you can wear on any occasion.',
      imageUrl: 'images/nike1.jpg',
    ),
    Product(
      name: 'Converse Unisex Chuck Taylor All Star High',
      price: 121.99,
      category: 'Men',
      brand: 'Converse',
      description: 'Ortholog sock-liner for an extra layer of padding that is added inside the shoe to provide added cushioning and support for the foot. This feature can help to improve comfort and reduce the risk of injury.',
      imageUrl: 'images/converse.jpg',
    ),
    Product(
      name: 'Mens Linen Shirt',
      price: 39.99,
      category: 'Men',
      brand: 'Marks & Spencer',
      description: 'The casual short sleeve shirt is made of high-quality cotton and linen fabric with anti-shrink treatment, soft and comfortable,easy to iron, lightweight and cool ,good breathability.',
      imageUrl: 'images/shirt.jpg',
    ),
    Product(
      name: 'COOFANDY Mens Linen Casual Short',
      price: 56.99,
      category: 'Men',
      brand: 'COOFANDY',
      description: 'Coofandy casual beach shirt is well-made of superior linen and mixture material. Soft, lightweight, breathable, refreshing, stretch, free Wrinkle and no ironing required, perfectly suitable for all seasons.',
      imageUrl: 'images/red.jpg',
    ),
    Product(
      name: 'Women Orthopedic Sneakers',
      price: 29.99,
      category: 'Women',
      brand: 'Orthotic',
      description: 'These sneakers have an embedded cushioning air cushion that buffers the walking and standing pressure. They also reduce the load on the joints so that you can stand easily and comfortably.',
      imageUrl: 'images/dress.jpg',
    ),
    Product(
      name: 'Linen Pants Joggers',
      price: 19.99,
      category: 'Women',
      brand: 'linen',
      description: 'Women pants is made of super comfortable and soft linen and cotton fabric, which is skin-friendly, breathable and durable to wear.',
      imageUrl: 'images/pant.jpg',
    ),
    Product(
      name: 'Long Sleeve Linen Cotton Shirt',
      price: 59.99,
      category: 'Men',
      brand: 'Adrianna',
      description: 'Cotton linen button down shirts with patch pocket at chest is a fashion style and a must-have item in everyone wardrobe. Grandad collar, curved hem and loose fit design make you look casual and handsome.',
      imageUrl: 'images/linen.jpg',
    ),
  ];

  ProductListPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Product List'),
      ),
      body: ListView.builder(
        itemCount: products.length,
        itemBuilder: (context, index) {
          final product = products[index];
          return GestureDetector(
            onTap: () {
              Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) =>ProductsDetailsPage(product: product)
                  )
              );
            },
            child: Card(
              elevation: 4,
              margin: const EdgeInsets.symmetric(horizontal: 10.0, vertical: 5.0),
              child: Row(
                children: [
                  Hero(

                    tag: product.imageUrl,
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Image.asset(
                        product.imageUrl,
                        width: 125,
                        height: 155,
                        fit: BoxFit.cover,
                      ),
                    ),
                  ),
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              product.name,
                              style: const TextStyle(fontSize: 16.0,fontWeight: FontWeight.bold),
                            ),
                            const SizedBox(height: 5.0),
                            Text('Price: \$${product.price.toStringAsFixed(2)}'),
                            const SizedBox(height: 5.0),
                            Text('Category: ${product.category}'),
                            const SizedBox(height: 5.0),
                            Text('Brand: ${product.brand}'),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
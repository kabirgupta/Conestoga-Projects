var fullImgBox= document.getElementById("fullImgBox");
var fullImg= document.getElementById("fullImg");

function openFullImg(picture)
{
	fullImgBox.style.display= "flex";
	fullImg.src= picture;
}

function closeFullImg()
{
	fullImgBox.style.display= "none";	
}



"use strict";
$(document).ready(function () {
  
  let imgCache_1 = [];
  $("#slides_12 img").each((index, img) => {
    const image = new Image();
    image.src = $(img).attr("src");
    image.title = $(img).attr("alt");
    imgCache_1[index] = image;
  });

  
  let image_count = 1;
  setInterval(() => {
    $("#slide_123").fadeOut(2000, () => {
      image_count = (image_count + 1) % imgCache_1.length;
      const next_img = imgCache_1[image_count];
      $("#slide_123").attr("src", next_img.src).fadeIn(2000);
    });
  }, 2000);
  
});

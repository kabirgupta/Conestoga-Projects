"use strict"
 $("#sign-in form").submit( evt => {
        let isValid = true;
const emailPattern = /\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,4}\b/;
        const email = $ ("#email").val().trim();
        if(email == "") {
            $("#email").next().text("This field is required.");
            isValid = false;
        }
        else if(!emailPattern.test(email)) {
            $("#email").next().text("Please enter a valid email address.");
            isValid = false;
        }
        else {
            $("#email").next().text("");
        }

        const password = $("#password").val().trim();
        if(password.length < 6) {
            $("#password").next().text("Password must be 6 or more characters.");
            isValid = false;
        }
        else {
            $("#password").next().text("");
        }
});
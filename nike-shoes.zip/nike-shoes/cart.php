<?php
require_once(__DIR__ . '/db.php');
$conn = new DB();
require_once('header.php');
?>
<!-- Start Banner Area -->
<section class="banner-area organic-breadcrumb">
    <div class="container">
        <div class="breadcrumb-banner d-flex flex-wrap align-items-center justify-content-end">
            <div class="col-first">
                <h1>Shopping Cart</h1>
                <nav class="d-flex align-items-center">
                    <a href="index.php">Home<span class="lnr lnr-arrow-right"></span></a>
                    <a href="#">Cart</a>
                </nav>
            </div>
        </div>
    </div>
</section>
<!-- End Banner Area -->
<?php
$total = 0;
if (isset($_SESSION['cart'])) {
    ?>
    <!--================Cart Area =================-->
    <section class="cart_area">
        <div class="container">
            <div class="cart_inner">
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th scope="col">Product</th>
                                <th scope="col">Price</th>
                                <th scope="col">Quantity</th>
                                <th scope="col">Total</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            foreach ($_SESSION['cart'] as $products) {
                                $data = $conn->productById($products['productId']);
                                if (!empty($data)) {
                                    foreach ($data as $product) {
                                        $total += $products['quantity']*$product[4];
                                        ?>

                                        <tr>
                                            <td>
                                                <div class="media">
                                                    <div class="d-flex">
                                                        <img style="width:100px;height:100px" src="<?php echo htmlspecialchars($product[3]) ?>" alt="">
                                                    </div>
                                                    <div class="media-body">
                                                        <p><?php echo htmlspecialchars($product[1]) ?></p>
                                                    </div>
                                                </div>
                                            </td>
                                            <td>
                                                <h5><?php echo htmlspecialchars($product[4]) ?></h5>
                                            </td>
                                            <td>
                                                <h5><?php echo htmlspecialchars($products['quantity']) ?></h5>
                                            </td>
                                            
                                            <td>
                                                <h5>$<?php echo htmlspecialchars(($products['quantity']*$product[4])) ?></h5>
                                            </td>
                                        </tr>
                                        <?php
                                    }
                                }
                            } ?>
                            <tr>
                                <td>

                                </td>
                                <td>

                                </td>
                                <td>
                                    <h5>Subtotal</h5>
                                </td>
                                <td>
                                    <h5>$<?php echo htmlspecialchars($total) ?></h5>
                                </td>
                            </tr>
                           
                            <tr class="out_button_area">
                                <td>

                                </td>
                                <td>

                                </td>
                                <td>

                                </td>
                                <td>
                                    <div class="checkout_btn_inner d-flex align-items-center">
                                        <a class="gray_btn" href="shop.php">Continue Shopping</a>
                                        <a class="primary-btn" href="checkout-page.php">Proceed to checkout</a>
                                    </div>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </section>
    <!--================End Cart Area =================-->
    <?php
}

require_once('footer.php');
?>
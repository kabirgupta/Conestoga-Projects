<?php
require_once(__DIR__ . '/db.php');
$conn = new DB();
require_once('header.php');
if (!isset($_SESSION['email']))
    header('location:login.php');
?>
<!-- Start Banner Area -->
<section class="banner-area organic-breadcrumb">
    <div class="container">
        <div class="breadcrumb-banner d-flex flex-wrap align-items-center justify-content-end">
            <div class="col-first">
                <h1>Checkout</h1>
                <nav class="d-flex align-items-center">
                    <a href="index.php">Home<span class="lnr lnr-arrow-right"></span></a>
                    <a href="#">Checkout</a>
                </nav>
            </div>
        </div>
    </div>
</section>
<!-- End Banner Area -->
<section class="checkout_area section_gap">
    <div class="container">

        <div class="billing_details">
            <div class="row">
                <div class="col-lg-12">
                    <h3>Billing Details</h3>
                    <form class="row contact_form" method="post">
                        <div class="col-md-6 form-group p_star">
                            <input required type="text" class="form-control" id="first" name="fname">
                            <span class="placeholder" data-placeholder="First name"></span>
                        </div>
                        <div class="col-md-6 form-group p_star">
                            <input required type="text" class="form-control" id="last" name="lname">
                            <span class="placeholder" data-placeholder="Last name"></span>
                        </div>

                        <div class="col-md-6 form-group p_star">
                            <input required type="text" class="form-control" id="number" name="number">
                            <span class="placeholder" data-placeholder="Phone number"></span>
                        </div>
                        <div class="col-md-6 form-group p_star">
                            <input required type="email" class="form-control" id="email" name="compemailany">
                            <span class="placeholder" data-placeholder="Email Address"></span>
                        </div>
                        <div class="col-md-12 form-group p_star">
                            <input required type="text" class="form-control" id="add1" name="add1">
                            <span class="placeholder" data-placeholder="Address line 01"></span>
                        </div>
                        <div class="col-md-12 form-group p_star">
                            <input required type="text" class="form-control" id="city" name="city">
                            <span class="placeholder" data-placeholder="Town/City"></span>
                        </div>
                        <div class="col-md-12 form-group p_star">
                            <select class="country_select">
                                <option value="1">US</option>
                                <option value="2">Canada</option>
                            </select>
                        </div>
                        <div class="col-md-12 form-group">
                            <input required type="text" class="form-control" id="zip" name="zip"
                                placeholder="Postcode/ZIP">
                        </div>
                        <div class="checkout_btn_inner d-flex align-items-center">
                            <input type="submit" name="placed" class="primary-btn" value="Proceed to checkout"> 
                        </div>
                    </form>
                </div>

            </div>
        </div>
    </div>
</section>
<?php
require_once('footer.php');
?>
<?php
if (isset($_POST['placed'])) {
    foreach ($_SESSION['cart'] as $product) {
        $data = $conn->orderPlaced($product['productId'],$_POST['fname']);
    }
    echo "<script>alert('Order placed!');window.location.href = 'confirmation.php';</script>";
}
?>
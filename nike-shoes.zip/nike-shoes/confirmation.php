<?php
require_once(__DIR__ . '/db.php');
$conn = new DB();
require_once('header.php');
if (!isset($_SESSION['email']))
    header('location:login.php');
?>
<section class="banner-area organic-breadcrumb">
    <div class="container">
        <div class="breadcrumb-banner d-flex flex-wrap align-items-center justify-content-end">
            <div class="col-first">
                <h1>Checkout</h1>
                <nav class="d-flex align-items-center">
                    <a href="index.php">Home<span class="lnr lnr-arrow-right"></span></a>
                    <a href="#">Confirmation Page</a>
                </nav>
            </div>
        </div>
    </div>
</section>
<section class="checkout_area section_gap">
    <div class="container">
        <h1> Thank you for ordering with us</h1>
        <div class="checkout_btn_inner d-flex align-items-center">
                            <a href="invoice.php"  class="primary-btn">Download your invoice</a> 
                        </div>
    </div>
</section>
<?php
require_once('footer.php');
?>
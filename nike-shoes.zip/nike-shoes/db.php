<?php
session_start();
class DB
{
    private $conn;
    function __construct()
    {
        try {
            $this->conn = new PDO('mysql:host=localhost;dbname=nikeDB', 'root', '');
        } catch (Exception $ex) {
            echo $ex->getMessage();
            die();
        }
        $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    }
    function insertUser($email, $password)
    {
        $fl = True;
        $q = "insert into users(email,password) values(:email,:password)";
        $stmt = $this->conn->prepare($q);
        $stmt->bindParam(':email', $email);
        $stmt->bindParam(':password', $password);
        try {
            $fl = $stmt->execute();
        } catch (PDOException $ex) {

            echo $ex->getMessage();
        }
        return $fl;
    }
    function loginUser($email, $password)
    {
        $fl = True;
        $q = "select * from users where email=:email and password=:password";
        $stmt = $this->conn->prepare($q);
        $stmt->bindParam(':email', $email);
        $stmt->bindParam(':password', $password);
        try {
            $fl = $stmt->execute();
        } catch (PDOException $e) {
            echo $e->getMessage();
        }
        $fl = $stmt->rowCount();
        return $fl;
    }
    function getAdminProduct($category)
    {
        if($category==""){
            $q = "SELECT * FROM products";
            $stmt = $this->conn->prepare($q);
            $stmt->execute();
            $stmt->setFetchMode(PDO::FETCH_NUM);
            return $stmt->fetchAll();
        }else{
            $q = "SELECT * FROM products where type=:type";
            $stmt = $this->conn->prepare($q);
            $stmt->bindParam(':type', $category);
            $stmt->execute();
            $stmt->setFetchMode(PDO::FETCH_NUM);
            return $stmt->fetchAll();
        }
        
    }
    function insertProduct($name, $type, $price, $company, $details, $productUrl)
    {
        $fl = True;
        $q = "insert into products(name,company,productUrl,price,details,type) values(:name,:company,:image,:price,:details,:type)";
        $stmt = $this->conn->prepare($q);
        $stmt->bindParam(':name', $name);
        $stmt->bindParam(':company', $company);
        $stmt->bindParam(':image', $productUrl);
        $stmt->bindParam(':price', $price);
        $stmt->bindParam(':details', $details);
        $stmt->bindParam(':type', $type);
        try {
            $fl = $stmt->execute();
        } catch (PDOException $ex) {

            echo $ex->getMessage();
        }
        return $fl;
    }
    function updateProduct($name, $type, $price, $company, $details, $productUrl, $id)
    {
        $fl = True;
        $q = "update products set name=:name,company=:company,productUrl=:image,price=:price,details=:details,type=:type where id=:id";
        $stmt = $this->conn->prepare($q);
        $stmt->bindParam(':name', $name);
        $stmt->bindParam(':company', $company);
        $stmt->bindParam(':image', $productUrl);
        $stmt->bindParam(':price', $price);
        $stmt->bindParam(':details', $details);
        $stmt->bindParam(':type', $type);
        $stmt->bindParam(':id', $id);
        try {
            $fl = $stmt->execute();
        } catch (PDOException $ex) {

            echo $ex->getMessage();
        }
        return $fl;
    }
    function delete($id)
    {
        $q = "delete from products where id=:id";
        $stmt = $this->conn->prepare($q);
        $stmt->bindparam(':id', $id);
        try {

            $flag = $stmt->execute();

        } catch (PDOException $e) {
            echo $e->getMessage();
        }
        return $flag;
    }
    function productById($id)
    {
        $q = "select * from products where id=:id";
        $stmt = $this->conn->prepare($q);
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        $stmt->setFetchMode(PDO::FETCH_NUM);
        return $stmt->fetchAll();
    }
    function orderPlaced($productId, $user)
    {
        $fl = True;
        $q = "insert into orders(productId,user,orderedAt) values(:id,:user,:date)";
        $stmt = $this->conn->prepare($q);
        $stmt->bindParam(':id', $productId);
        $stmt->bindParam(':user', $user);
        $stmt->bindParam(':date', date("Y/m/d"));
        try {
            $fl = $stmt->execute();
        } catch (PDOException $ex) {

            echo $ex->getMessage();
        }
        return $fl;
    }
}


?>
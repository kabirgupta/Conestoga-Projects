<?php
require_once(__DIR__ . '/db.php');
$conn = new DB();
if(isset($_GET['id'])){
    $flag = $conn->delete($_GET['id']);
    if ($flag) {
        echo "<script>alert('Deleted!')</script>";
        header('location:productList.php');
    } else{
        echo "<script>alert('Error!')</script>";
        header('location:productList.php');
    }
}else{
    header('location:productList.php');
}

?>
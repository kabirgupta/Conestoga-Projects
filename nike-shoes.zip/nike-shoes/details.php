<?php
require_once(__DIR__ . '/db.php');
$conn = new DB();
require_once('header.php');
if (!isset($_GET['id']))
    header('location:shop.php');
?>
<?php
$data = $conn->productById($_GET['id']);
if (!empty($data)) {
    foreach ($data as $product) {
        ?>
        <!-- Start Banner Area -->
        <section class="banner-area organic-breadcrumb">
            <div class="container">
                <div class="breadcrumb-banner d-flex flex-wrap align-items-center justify-content-end">
                    <div class="col-first">
                        <h1>Product Details Page</h1>

                    </div>
                </div>
            </div>
        </section>
        <!-- End Banner Area -->

        <!--================Single Product Area =================-->
        <div class="product_image_area">
            <div class="container">
                <div class="row s_product_inner">
                    <div class="col-lg-6">
                        <div class="s_Product_carousel">
                            <div class="single-prd-item">
                                <img class="img-fluid" src="<?php echo htmlspecialchars($product[3]) ?>" alt="">
                            </div>
                            <div class="single-prd-item">
                                <img class="img-fluid" src="img/category/s-p1.jpg" alt="">
                            </div>
                            <div class="single-prd-item">
                                <img class="img-fluid" src="img/category/s-p1.jpg" alt="">
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-5 offset-lg-1">
                        <div class="s_product_text">
                            <h3>
                                <?php echo htmlspecialchars($product[1]) ?>
                            </h3>
                            <h2>$
                                <?php echo htmlspecialchars($product[4]) ?>
                            </h2>
                            <ul class="list">
                                <li><a class="active" href="#"><span>Category</span> :
                                        <?php echo htmlspecialchars($product[6]) ?>
                                    </a></li>
                            </ul>
                            <p>
                                <?php echo htmlspecialchars($product[5]) ?>
                            </p>
                            <form method="post">
                                <div class="product_count">
                                    <label for="qty">Quantity:</label>
                                    <input type="text" name="qty" id="sst" maxlength="12" value="1" title="Quantity:"
                                        class="input-text qty">
                                    <button
                                        onclick="var result = document.getElementById('sst'); var sst = result.value; if( !isNaN( sst )) result.value++;return false;"
                                        class="increase items-count" type="button"><i class="lnr lnr-chevron-up"></i></button>
                                    <button
                                        onclick="var result = document.getElementById('sst'); var sst = result.value; if( !isNaN( sst ) &amp;&amp; sst > 0 ) result.value--;return false;"
                                        class="reduced items-count" type="button"><i class="lnr lnr-chevron-down"></i></button>
                                </div>
                                <div class="card_area d-flex align-items-center">
                                    <button name="addCart" class="primary-btn">Add to cart</button>
                                    </div>
                            </form>


                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--================End Single Product Area =================-->

        <!--================Product Description Area =================-->
        <section class="product_description_area">
            <div class="container">
                <ul class="nav nav-tabs" id="myTab" role="tablist">
                    <li class="nav-item">
                        <a class="nav-link active" id="home-tab" data-toggle="tab" href="#home" role="tab" aria-controls="home"
                            aria-selected="true">Description</a>
                    </li>

                </ul>
                <div class="tab-content" id="myTabContent">
                    <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
                        <p>
                            <?php echo htmlspecialchars($product[5]) ?>
                        </p>
                    </div>
                </div>
            </div>
        </section>
        <!--================End Product Description Area =================-->
        <?php
    }
}
require_once('footer.php');
?>

<?php
if (isset($_POST['addCart']) && isset($_POST['qty'])) {
    if (!isset($_SESSION['cart'])) {
        $_SESSION['cart'] = array();
    }
    // Add the item to the cart
    $item = array(
        'productId' => $_GET["id"],
        'quantity' => $_POST['qty']
    );
    array_push($_SESSION['cart'], $item);
    echo "<script>alert('Added to cart');</script>";
}
?>
<?php
require('fpdf185/fpdf.php');
require_once(__DIR__ . '/db.php');
$date = date('Y-m-d');
if (!isset($_SESSION['email']))
    header('location:login.php');
class PDF extends FPDF
{
    function Header()
    {
        $this->Image('img/logo.png', 85, 10, 50);
        $this->Ln(20); 
        $this->SetFont('Arial', 'B', 13);
        $this->Cell(0, 10, 'Nike Store!', 0, 0, 'C');
        $this->Ln(20); 
    }
    function Footer()
    {
        $this->SetY(-15);
        $this->SetFont('Arial', 'I', 8);
        $this->Cell(0, 10, 'Page ' . $this->PageNo(), 0, 0, 'C');
    }
}
$pdf = new PDF();
$pdf->AddPage();
$pdf->SetFont('Arial', 'B', 16);
$pdf->Cell(0, 10, 'Nike Store inovice', 0, 1, 'C');
$pdf->Ln();
$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(0, 10, 'Customer Name: ' . isset($_SESSION['email'])?$_SESSION['email']:"Guest user", 0, 1);
$pdf->Cell(0, 10, 'Date: ' . $date, 0, 1);

$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(60, 10, 'Product Name', 1);
$pdf->Cell(30, 10, 'Price', 1);
$sub = 0;
if (isset($_SESSION['cart'])) {
    $obj1 = new DB();
    foreach ($_SESSION['cart'] as $product) {
        $r = $obj1->productById($product["productId"]);
        if (!empty($r)) {
            foreach ($r as $a) {
                $pdf->SetFont('Arial', '', 12);
                $pdf->Ln();
                $pdf->Cell(60, 10, $a[2], 1);
                $sub += $a[4];
                $pdf->Cell(30, 10, $a[4], 1);
            }
        }
    }
}
$pdf->Ln();
$pdf->Cell(60, 10, "Thank you!", 1);
$pdf->Ln();
$pdf->Output('your-invoice.pdf', 'D');
?>
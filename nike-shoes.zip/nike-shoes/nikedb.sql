-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 15, 2023 at 07:38 AM
-- Server version: 10.4.10-MariaDB
-- PHP Version: 7.3.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `nikedb`
--

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `productId` int(11) DEFAULT NULL,
  `user` varchar(50) DEFAULT NULL,
  `orderedAt` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `productId`, `user`, `orderedAt`) VALUES
(1, 5, 'saurabh', '2023-08-15'),
(2, 4, 'saurabh', '2023-08-15'),
(3, 5, 'saurabh', '2023-08-15'),
(4, 4, 'saurabh', '2023-08-15'),
(5, 4, 'saurabh', '2023-08-15'),
(6, 5, 'saurabh', '2023-08-15'),
(7, 4, 'saurabh', '2023-08-15'),
(8, 4, 'saurabh', '2023-08-15'),
(9, 3, 'saurabh', '2023-08-15');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `company` varchar(100) DEFAULT NULL,
  `productUrl` varchar(100) DEFAULT NULL,
  `price` double DEFAULT NULL,
  `details` varchar(1000) DEFAULT NULL,
  `Type` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `company`, `productUrl`, `price`, `details`, `Type`) VALUES
(2, 'Nike Air Force 1 \'07', 'Nike', 'uploads/Grand_Court_Lifestyle_Tennis_Lace-Up_Shoes_White_GW6511_01_standard.jpg', 192, 'Double the Swooshes, double the fun. We put a fresh spin on what you know best: durably stitched overlays, clean finishes and subtly bold details that make you shine. Two Swoosh logos on the side show your love for the brand that does it best.\r\n\r\n\r\nBenefits\r\n\r\nStitched leather overlays add heritage style, durability and support.\r\nOriginally designed for performance hoops, Nike Air cushioning adds lightweight comfort.\r\nLow-cut silhouette adds a clean, streamlined look.', 'men'),
(3, 'Nike Free Metcon 5', 'Nike', 'uploads/Superstar_XLG_Shoes_Black_IG9777_01_standard.jpg', 160, 'When your workouts wade into the nitty-gritty, the Nike Free Metcon 5 can meet you in the depths, help you dig deep to find that final ounce of force and come out of the other side on a high. It matches style with substance, forefoot flexibility with back-end stability, perfect for flying through a cardio day or enhancing your agility. A revamped upper offers easier entry with a collar made just for your ankle.\r\n\r\n\r\nRevamped Upper\r\n\r\nA breathable, lightweight upper has a comfortable, sock-like feel with a 7/8-length inner sleeve and provides easy entry. Plush foam around the collar provides comfort and support around your ankle.\r\n\r\n\r\nStability for Strength\r\n\r\nThe wide heel creates a solid base for lifting. A softer foam core cushions your foot, while a firmer outer layer is durable and stable. Wide internal webbing distributes pressure around your midfoot for a comfortable yet secure feel during sudden stops and quick cuts.', 'men'),
(4, 'Nike Air Force 1 Low By You', 'Nike', 'uploads/Runfalcon_3_Shoes_Blue_HP7555_01_standard.jpg', 179, 'Shine in satin, stay classic in canvas or get luxe with leather. No matter what you choose, these AF-1s are all about you. 12 colour choices and an additional gum rubber option for the sole mean your design is destined to be one of a kind—just like you.\r\n\r\nWHAT\'S YOUR BASE?\r\n\r\nSatin, canvas or leather—choose your favourite or mix it up with all 3.\r\n\r\nCOLOUR-UP\r\n\r\nGo crazy with colour or keep it monochromatic. Our 12 colour options are inspired by the classic Air Force 1 and the athletes who made them popular.\r\n\r\nMAKE IT PERSONAL\r\n\r\nAdd up to 3 characters on the heel—you can even mix it up with different messages on the left and the right.', 'women'),
(5, 'Jordan 1 Mid', 'Nike', 'uploads/Superstar_XLG_Shoes_Black_IG9777_04_standard.jpg', 85, 'Pick pink for the win! This pair pops to life with a bright mix of rosy hues. All the classic Jordan comforts are there too: foam in the sole for a cushioned step, and that sturdy rubber cupsole for comfort.\r\n\r\n\r\nBenefits\r\n\r\nLeather offers durability and structure.\r\nSolid rubber outsoles add traction for little feet.\r\n\r\nProduct Details\r\n\r\nClassic laces\r\nWings logo stamped on the collar\r\nStitched-down Swoosh logo\r\nJumpman design on the tongue\r\nColour Shown: White/Fierce Pink/Medium Soft Pink\r\nStyle: FD8781-116\r\nCountry/Region of Origin: Indonesia', 'men'),
(6, 'Air Jordan 1 Low SE', 'Nike', 'uploads/j.jpg', 110, 'New colours and fresh textures give you an updated AJ1—without losing the familiar feel. This edition is made from premium suede and leather, cushioned with plenty of Nike Air, and decked out with colour-blocking and an elephant print Swoosh for a staple sneaker with modern expression.\r\n\r\n\r\nBenefits\r\n\r\nLeather offers durability and structure.\r\nEncapsulated Nike Air-Sole units provide lightweight cushioning.\r\nSolid rubber outsoles give you traction on a variety of surfaces.\r\n\r\nProduct details\r\n\r\nWings logo stamped on heel\r\nStitched-down Swoosh logo\r\nJumpman Air design on tongue\r\nColour Shown: Hemp/White/Black/Light British Tan\r\nStyle: DZ5368-201\r\nCountry/Region of Origin: Indonesia', 'women'),
(7, 'Nike Air Max Plus', 'Nike', 'uploads/e.jpg', 170, 'CLASSIC STYLE AND COMFORT.\r\n\r\n\r\nThe Nike Air Max Plus brings you legendary \'Tuned\' Air cushioning for extra comfort. It keeps the original inspiration: wavy lines that look like palm leaves and a whale\'s tail near the bottom.\r\n\r\n\r\nClassic Style\r\n\r\nWavy design lines are inspired by beachy sunsets. Look out for a whale\'s tail near the middle of the shoe.\r\n\r\n\r\nClassic Comfort\r\n\r\nMax Air cushioning gives you lightweight comfort. Foam feels soft and comfortable.\r\n\r\n\r\nProduct Details\r\n\r\nNot intended for use as Personal Protective Equipment (PPE)\r\nColour Shown: Black/Black/Black\r\nStyle: CD0609-001\r\nCountry/Region of Origin: Indonesia', 'women');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `email` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `email`, `password`) VALUES
(1, 'raman@gmail.com', '123456');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

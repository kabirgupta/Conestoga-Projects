<?php
require_once(__DIR__ . '/db.php');
$conn = new DB();
if (!isset($_SESSION['email']) && $_SESSION['email'] != "ram@gmail.com")
    header('location:login.php')
        ?>
    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Admin Product list</title>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css"
            integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    </head>

    <body>
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <a class="navbar-brand" href="productList.php">Admin Panel</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item active">
                        <a class="nav-link" href="add.php">Add Product</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="productList.php">Product listing</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="logout.php">Logout</a>
                    </li>
                </ul>
            </div>
        </nav>
        <div class="container mt-5">
            <table class="table table-bordered table-responsive">
                <tr>
                    <td>
                        Pictures
                    </td>
                    <td>
                        Product
                    </td>
                    <td>
                        Company
                    </td>
                    <td>
                        Type
                    </td>
                    <td>
                        Unit Price
                    </td>
                    <td>
                        Details
                    </td>
                    <td>
                    </td>
                </tr>
                <?php
$data = $conn->getAdminProduct("");
if (!empty($data)) {
    foreach ($data as $product) {
        ?>
                    <tr>
                        <td>
                            <img width="100px" height="100px" src="<?php echo htmlspecialchars($product[3]) ?>"
                                alt="<?php echo htmlspecialchars($product[3]) ?>" />
                        </td>
                        <td>
                            <?php echo htmlspecialchars($product[1]) ?>
                        </td>
                        <td>
                            <?php echo htmlspecialchars($product[2]) ?>
                        </td>
                        <td>
                            <?php echo htmlspecialchars($product[6]) ?>
                        </td>
                        <td>
                            $
                            <?php echo htmlspecialchars($product[4]) ?>
                        </td>
                        <td>
                            <?php echo htmlspecialchars($product[5]) ?>
                        </td>
                        <td>
                            <a href="update.php?id=<?php echo htmlspecialchars($product[0]) ?>">Update</a>
                            <a 
                                href="delete.php?id=<?php echo htmlspecialchars($product[0]) ?>">Delete</a>
                        </td>
                    </tr>
                    <?php
    }
}
?>
        </table>
    </div>
</body>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.min.js"
    integrity="sha384-cuYeSxntonz0PPNlHhBs68uyIAVpIIOZZ5JqeqvYYIcEL727kskC66kF92t6Xl2V"
    crossorigin="anonymous"></script>

</html>
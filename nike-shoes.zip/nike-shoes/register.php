<?php
require_once(__DIR__ .'/db.php');
require_once('header.php');
?>
<!-- Start Banner Area -->
<section class="banner-area organic-breadcrumb">
    <div class="container">
        <div class="breadcrumb-banner d-flex flex-wrap align-items-center justify-content-end">
            <div class="col-first">
                <h1>Register</h1>
                <nav class="d-flex align-items-center">
                    <a href="/">Home<span class="lnr lnr-arrow-right"></span></a>
                    <a href="#">Register</a>
                </nav>
            </div>
        </div>
    </div>
</section>
<!-- End Banner Area -->

<!--================Login Box Area =================-->
<section class="login_box_area section_gap">
    <div class="container">
        <div class="row">
            <div class="col-lg-6">
                <div class="login_box_img">
                    <img class="img-fluid" src="img/login.jpg" alt="">
                    <div class="hover">
                        <h4>Aleady have an account?</h4>
                        <p>There are advances being made in science and technology everyday, and a good example of this
                            is the</p>
                        <a class="primary-btn" href="login.php">Login</a>
                    </div>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="login_form_inner">
                    <h3>Register</h3>
                    <form class="row login_form" method="POST" id="contactForm"
                        novalidate="novalidate">
                        <div class="col-md-12 form-group">
                            <input required type="email" class="form-control" id="email" name="email" placeholder="Email"
                                onfocus="this.placeholder = ''" onblur="this.placeholder = 'Email'">
                        </div>
                        <div class="col-md-12 form-group">
                            <input required type="password" class="form-control" id="password" name="password" placeholder="Password"
                                onfocus="this.placeholder = ''" onblur="this.placeholder = 'Password'">
                        </div>
                        <div class="col-md-12 form-group">
                            <button type="submit" name="submit" class="primary-btn">Register</button>
                            
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>
<!--================End Login Box Area =================-->

<?php
require_once('footer.php');
?>
<?php
if (isset($_POST['submit'])) {
    $db = new DB();
    $data = $db->insertUser($_POST['email'], $_POST['password']);
        if ($data == 1) {
            $_SESSION['email'] = $_POST['email'];
            echo "<script>window.location.href = 'index.php';</script>";
        } else {
            echo "<script>alert('Some errors occurs.')</script>";
        }
}
?>
<?php
require_once(__DIR__ . '/db.php');
$conn = new DB();
require_once('header.php');
?>
    <!-- Start Banner Area -->
	<section class="banner-area organic-breadcrumb">
		<div class="container">
			<div class="breadcrumb-banner d-flex flex-wrap align-items-center justify-content-end">
				<div class="col-first">
					<h1>Shop page</h1>
					
				</div>
			</div>
		</div>
	</section>
	<!-- End Banner Area -->
    <div class="container">
	<div class="row">
		<?php
		$data = $conn->getAdminProduct(isset($_GET["type"])?$_GET["type"]:"");
		if (!empty($data)) {
			foreach ($data as $product) {
				?>
				<!-- single product -->
				<div class="col-lg-3 col-md-6">
					<a href="details.php?id=<?php echo htmlspecialchars($product[0]) ?>">
						<div class="single-product">
							<img class="img-fluid" src="<?php echo htmlspecialchars($product[3]) ?>" alt="">
							<div class="product-details">
								<h6>
									<?php echo htmlspecialchars($product[1]) ?>
								</h6>
								<div class="price">
									<h6>$
										<?php echo htmlspecialchars($product[4]) ?>
									</h6>

								</div>

							</div>
						</div>
					</a>
				</div>
				<?php

			}
		}
		?>


	</div>
</div>
<?php
require_once('footer.php');
?>
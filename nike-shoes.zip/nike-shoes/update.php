<?php
require_once(__DIR__ . '/db.php');
$conn = new DB();
if (!isset($_SESSION['email']) && $_SESSION['email'] != "ram@gmail.com")
    header('location:login.php');
if (!isset($_GET['id']))
    header('location:productList.php');
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Product Add</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css"
        integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <a class="navbar-brand" href="/productList.php">Admin Panel</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav"
            aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item active">
                    <a class="nav-link" href="add.php">Add Product</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="productList.php">Product listing</a>
                </li>
                <li class="nav-item">
                        <a class="nav-link" href="logout.php">Logout</a>
                    </li>
            </ul>
        </div>
    </nav>
    <div class="container mt-5">
        <?php
        $data = $conn->productById($_GET['id']);
        if (!empty($data)) {
            foreach ($data as $product) {
                ?>
                <h2>Update Product</h2>
                <form method="post" enctype="multipart/form-data">
                    <div class="row mt-2">
                        <div class="col-5">
                            <input required value="<?php echo htmlspecialchars($product[1]) ?>" class="form-control" type="text"
                                name="name" placeholder="product name" />
                        </div>
                    </div>
                    <div class="row mt-2">
                        <div class="col-5">
                            <select id="category" required class="form-control" name="category">
                                <option>men</option>
                                <option>women</option>
                            </select>
                        </div>

                    </div>
                    <div class="row mt-2">
                        <div class="col-5">
                            <input required value="<?php echo htmlspecialchars($product[2]) ?>" class="form-control" type="text"
                                name="company" placeholder="Company" />
                        </div>
                    </div>

                    <div class="row mt-2">
                        <div class="col-5">
                            <input required class="form-control" value="<?php echo htmlspecialchars($product[4]) ?>"
                                type="number" name="price" placeholder="Price" />
                        </div>
                    </div>
                    <div class="row mt-2">
                        <div class="col-5">
                            <textarea required  name="details"
                                class="form-control" placeholder="details"><?php echo htmlspecialchars($product[5]) ?></textarea>
                        </div>
                    </div>
                    <div class="row mt-2">
                        <div class="col-5">
                            <input required type="file" name="productUrl" class="form-control" />
                        </div>
                    </div>
                    <div class="row mt-2">
                        <div class="col-5">
                            <input type="submit" value="Update" name="update" class="btn btn-primary" />
                            <a href="/productList.php" class="btn btn-outline-primary">Cancel</a>
                        </div>
                    </div>
                </form>
            <?php
            }
        }
        ?>
    </div>
</body>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.min.js"
    integrity="sha384-cuYeSxntonz0PPNlHhBs68uyIAVpIIOZZ5JqeqvYYIcEL727kskC66kF92t6Xl2V"
    crossorigin="anonymous"></script>

</html>
<?php
if (isset($_POST['update'])) {
    $db = new DB();
    $target_dir = "uploads/";
    $target_file = $target_dir . basename($_FILES["productUrl"]["name"]);
    $uploadOk = 1;
    $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

    // Check if image file is a actual image or fake image
    if (isset($_POST["submit"])) {
        $check = getimagesize($_FILES["productUrl"]["tmp_name"]);
        if ($check !== false) {
            echo "File is an image - " . $check["mime"] . ".";
            $uploadOk = 1;
        } else {
            echo "File is not an image.";
            $uploadOk = 0;
        }
    }

    // Check if file already exists
    if (file_exists($target_file)) {
        echo "Sorry, file already exists.";
        $uploadOk = 0;
    }

    // Check file size
    if ($_FILES["productUrl"]["size"] > 500000) {
        echo "Sorry, your file is too large.";
        $uploadOk = 0;
    }

    // Allow certain file formats
    if (
        $imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
        && $imageFileType != "gif"
    ) {
        echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
        $uploadOk = 0;
    }

    // Check if $uploadOk is set to 0 by an error
    if ($uploadOk == 0) {
        echo "<script>alert(Sorry, your file was not uploaded)</script>";
        // if everything is ok, try to upload file
    } else {
        if (move_uploaded_file($_FILES["productUrl"]["tmp_name"], $target_file)) {
            echo "<script>alert('file uploaded')</script>";
            $rc = $conn->updateProduct($_POST['name'], $_POST['category'], $_POST['price'], $_POST['company'], $_POST['details'], $target_file, $_GET['id']);
            if ($rc) {
                echo "<script>alert('Product updated!')</script>";
                header('location:productList.php');
            } else
                echo "<script>alert('Error in update!')</script>";
        } else {
            echo "<script>alert(Sorry, there was an error uploading your file.)</script>";
        }
    }
}
?>